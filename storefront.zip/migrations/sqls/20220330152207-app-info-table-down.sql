/* Replace with your SQL commands */

DROP TABLE app_info