/* Replace with your SQL commands */
CREATE TABLE countries (
    id SERIAL PRIMARY KEY ,
    name VARCHAR(100) ,
    created_at TIMESTAMP
)