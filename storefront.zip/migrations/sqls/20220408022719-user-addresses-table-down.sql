/* Replace with your SQL commands */
DROP TABLE user_addresses