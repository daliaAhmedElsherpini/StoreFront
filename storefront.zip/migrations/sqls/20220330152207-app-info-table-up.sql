/* Replace with your SQL commands */
CREATE TABLE app_info (
    id SERIAL PRIMARY KEY ,
    key VARCHAR(255) ,
    value text
)