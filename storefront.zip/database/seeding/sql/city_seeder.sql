INSERT INTO cities (name , country_id , created_at) VALUES ('Alex'  , 1 ,now());
INSERT INTO cities (name , country_id , created_at) VALUES ('cairo' , 1, now());
INSERT INTO cities (name , country_id , created_at) VALUES ('asuit' , 1 , now());
