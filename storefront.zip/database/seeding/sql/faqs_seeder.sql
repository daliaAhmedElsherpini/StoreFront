INSERT INTO faqs (question , answer , created_at) VALUES ('question' , 'answer' , now() );
INSERT INTO faqs (question , answer , created_at) VALUES ('question' , 'answer' , now() );
INSERT INTO faqs (question , answer , created_at) VALUES ('question' , 'answer' , now() );
INSERT INTO faqs (question , answer , created_at) VALUES ('question' , 'answer' , now() );
INSERT INTO faqs (question , answer , created_at) VALUES ('question' , 'answer' , now() );
INSERT INTO faqs (question , answer , created_at) VALUES ('question' , 'answer' , now() );
INSERT INTO faqs (question , answer , created_at) VALUES ('question' , 'answer' , now() );
INSERT INTO faqs (question , answer , created_at) VALUES ('question' , 'answer' , now() );
INSERT INTO faqs (question , answer , created_at) VALUES ('question' , 'answer' , now() );
INSERT INTO faqs (question , answer , created_at) VALUES ('question' , 'answer' , now() );
INSERT INTO faqs (question , answer , created_at) VALUES ('question' , 'answer' , now() );
INSERT INTO faqs (question , answer , created_at) VALUES ('question' , 'answer' , now() );
INSERT INTO faqs (question , answer , created_at) VALUES ('question' , 'answer' , now() );

