INSERT INTO products (title , stock , description, price , sale_price , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200, 140 , 1 ,  now());

INSERT INTO products (title , stock , description, price , sale_price , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200, 140 , 1 ,  now());

INSERT INTO products (title , stock , description, price  , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200 , 1 ,  now());

INSERT INTO products (title , stock , description, price , sale_price , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200, 140 , 1 ,  now());

INSERT INTO products (title , stock , description, price  , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200, 1 ,  now());

INSERT INTO products (title , stock , description, price , sale_price , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200, 140 , 1 ,  now());

INSERT INTO products (title , stock , description, price , sale_price , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200, 100 , 3 ,  now());

INSERT INTO products (title , stock , description, price , sale_price , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200, 110 , 3 ,  now());

INSERT INTO products (title , stock , description, price , sale_price , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200, 130 , 2 ,  now());

INSERT INTO products (title , stock , description, price , sale_price , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200, 160 , 3 ,  now());

INSERT INTO products (title , stock , description, price , sale_price , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200, 140 , 3 ,  now());

INSERT INTO products (title , stock , description, price , sale_price , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200, 140 , 2 ,  now());

INSERT INTO products (title , stock , description, price , sale_price , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200, 140 , 2 ,  now());

INSERT INTO products (title , stock , description, price , sale_price , category_id, created_at) 
VALUES ('product title' ,
10 ,
'description en',
200, 140 , 2 ,  now());
