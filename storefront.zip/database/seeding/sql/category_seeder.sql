
INSERT INTO categories (name , description  , created_at) VALUES ('bags' ,'description ' , now());

INSERT INTO categories (name , description  , created_at) VALUES ('glasses'  ,'description ' , now());

INSERT INTO categories (name , description  , created_at) VALUES ('makeup'  ,'description ' , now());

INSERT INTO categories (name , description  , created_at) VALUES ('home' ,'description ' , now());

