INSERT INTO contact_messages (name , email , subject , message , created_at) VALUES ('dalia' , 'dalia@gmail.com' , 'subject' , 'new message from me ' , now());
INSERT INTO contact_messages (name , email , subject , message , created_at) VALUES ('dalia' , 'dalia@gmail.com' , 'subject' , 'new message from me ' , now());
INSERT INTO contact_messages (name , email , subject , message , created_at) VALUES ('dalia' , 'dalia@gmail.com' , 'subject' , 'new message from me ' , now());
INSERT INTO contact_messages (name , email , subject , message , created_at) VALUES ('dalia' , 'dalia@gmail.com' , 'subject' , 'new message from me ' , now());
INSERT INTO contact_messages (name , email , subject , message , created_at) VALUES ('dalia' , 'dalia@gmail.com' , 'subject' , 'new message from me ' , now());
INSERT INTO contact_messages (name , email , subject , message , created_at) VALUES ('dalia' , 'dalia@gmail.com' , 'subject' , 'new message from me ' , now());
INSERT INTO contact_messages (name , email , subject , message , created_at) VALUES ('dalia' , 'dalia@gmail.com' , 'subject' , 'new message from me ' , now());
