INSERT INTO countries (name , created_at) VALUES ('Egypt' , now());
INSERT INTO countries (name , created_at) VALUES ('United Arab Emarites' , now());
INSERT INTO countries (name , created_at) VALUES ('saudi arabia' , now());
