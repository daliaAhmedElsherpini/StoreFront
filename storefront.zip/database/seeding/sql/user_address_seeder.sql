INSERT INTO user_addresses (user_id , city , country , street , flat_number , address , phone_number , email) 
VALUES (
1 ,
'Cairo' ,
'Country',
'mohammed bin zayed street',
10 ,
'abu dahabi united arab emarites',
'85785785785',
'email@email'
);